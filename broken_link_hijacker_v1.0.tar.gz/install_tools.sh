#!/bin/bash

# Installation script for broken link hijacking tool dependencies

echo "Installing external tools for broken link hijacking..."

# Create tools directory
mkdir -p ~/tools
cd ~/tools

# Install Go if not present
if ! command -v go &> /dev/null; then
    echo "Installing Go..."
    wget https://go.dev/dl/go1.21.0.linux-amd64.tar.gz
    sudo tar -C /usr/local -xzf go1.21.0.linux-amd64.tar.gz
    echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
    export PATH=$PATH:/usr/local/go/bin
fi

# Install subfinder
if ! command -v subfinder &> /dev/null; then
    echo "Installing subfinder..."
    go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
fi

# Install assetfinder
if ! command -v assetfinder &> /dev/null; then
    echo "Installing assetfinder..."
    go install github.com/tomnomnom/assetfinder@latest
fi

# Install gau
if ! command -v gau &> /dev/null; then
    echo "Installing gau..."
    go install github.com/lc/gau/v2/cmd/gau@latest
fi

# Install haktrails
if ! command -v haktrails &> /dev/null; then
    echo "Installing haktrails..."
    go install github.com/hakluke/haktrails@latest
fi

# Install katana
if ! command -v katana &> /dev/null; then
    echo "Installing katana..."
    go install github.com/projectdiscovery/katana/cmd/katana@latest
fi

# Install nuclei
if ! command -v nuclei &> /dev/null; then
    echo "Installing nuclei..."
    go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
fi

# Add Go bin to PATH if not already there
if [[ ":$PATH:" != *":$HOME/go/bin:"* ]]; then
    echo 'export PATH=$PATH:$HOME/go/bin' >> ~/.bashrc
    export PATH=$PATH:$HOME/go/bin
fi

echo "Installation completed!"
echo "Please run 'source ~/.bashrc' or restart your terminal to update PATH."
echo ""
echo "Installed tools:"
echo "- subfinder: $(which subfinder 2>/dev/null || echo 'Not found in PATH')"
echo "- assetfinder: $(which assetfinder 2>/dev/null || echo 'Not found in PATH')"
echo "- gau: $(which gau 2>/dev/null || echo 'Not found in PATH')"
echo "- haktrails: $(which haktrails 2>/dev/null || echo 'Not found in PATH')"
echo "- katana: $(which katana 2>/dev/null || echo 'Not found in PATH')"
echo "- nuclei: $(which nuclei 2>/dev/null || echo 'Not found in PATH')"

