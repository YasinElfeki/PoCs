# Broken Link Hijacking Tool

A comprehensive tool for automating the process of finding available usernames on social media platforms by analyzing broken links from target domains.

## Overview

This tool implements the broken link hijacking methodology described in the CyberBugs video series. It automates the process of:

1. **Subdomain Collection**: Gathering all subdomains for a target domain
2. **Link Collection**: Collecting historical and current URLs from various sources
3. **Username Extraction**: Extracting potential usernames from social media links
4. **Availability Check**: Verifying which usernames are available for registration

## Features

- **Multi-tool Integration**: Leverages popular security tools like `subfinder`, `gau`, `haktrails`, and `katana`
- **Platform Support**: Checks username availability on Instagram, Twitter, Facebook, GitHub, LinkedIn, YouTube, TikTok, and Snapchat
- **Modular Design**: Each step can be run independently or skipped if you have existing data
- **Rate Limiting**: Built-in delays to avoid overwhelming target platforms
- **Comprehensive Logging**: Detailed logging with configurable verbosity
- **Resume Capability**: Skip completed steps to resume interrupted runs

## Installation

### Prerequisites

- Python 3.6 or higher
- Go 1.19 or higher (for external tools)
- Internet connection

### Quick Setup

1. **Clone or download the tool**:
   ```bash
   # If you have the files, navigate to the directory
   cd broken_link_hijacker
   ```

2. **Install Python dependencies**:
   ```bash
   pip3 install -r requirements.txt
   ```

3. **Install external tools**:
   ```bash
   ./install_tools.sh
   source ~/.bashrc  # or restart your terminal
   ```

### Manual Tool Installation

If the automatic installation script doesn't work, you can install tools manually:

```bash
# Install Go tools
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install github.com/tomnomnom/assetfinder@latest
go install github.com/lc/gau/v2/cmd/gau@latest
go install github.com/hakluke/haktrails@latest
go install github.com/projectdiscovery/katana/cmd/katana@latest
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest

# Add Go bin to PATH
export PATH=$PATH:$HOME/go/bin
```

## Usage

### Basic Usage

```bash
python3 broken_link_hijacker.py --target example.com --output-dir ./results
```

### Advanced Usage

```bash
# Run with verbose logging
python3 broken_link_hijacker.py --target example.com --output-dir ./results --verbose

# Check only specific platforms
python3 broken_link_hijacker.py --target example.com --platforms instagram,twitter,github

# Skip certain steps (useful for resuming)
python3 broken_link_hijacker.py --target example.com --skip-subdomain-collection --skip-link-collection

# Run only username extraction and availability check
python3 broken_link_hijacker.py --target example.com --skip-subdomain-collection --skip-link-collection
```

### Command Line Options

- `--target`: Target domain (required)
- `--output-dir`: Output directory for results (default: ./results)
- `--verbose`: Enable verbose logging
- `--skip-subdomain-collection`: Skip subdomain enumeration
- `--skip-link-collection`: Skip link collection
- `--skip-username-extraction`: Skip username extraction
- `--skip-availability-check`: Skip availability verification
- `--platforms`: Comma-separated list of platforms to check

## Output Files

The tool generates several output files in the specified directory:

- `subdomains.txt`: List of discovered subdomains
- `all_links.txt`: All collected URLs from various sources
- `extracted_usernames.txt`: Extracted usernames with platform prefixes
- `available_usernames.txt`: Usernames confirmed as available
- `tool.log`: Detailed execution log

## Supported Platforms

- **Instagram**: `instagram.com/username`
- **Twitter**: `twitter.com/username`
- **Facebook**: `facebook.com/username`
- **GitHub**: `github.com/username`
- **LinkedIn**: `linkedin.com/in/username`
- **YouTube**: `youtube.com/user/username`
- **TikTok**: `tiktok.com/@username`
- **Snapchat**: `snapchat.com/add/username`

## How It Works

### 1. Subdomain Collection
Uses tools like `subfinder` and `assetfinder` to discover all subdomains associated with the target domain.

### 2. Link Collection
Employs multiple tools to gather URLs:
- **gau**: Gets URLs from Web Archive, Common Crawl, and VirusTotal
- **haktrails**: Collects URLs from various sources
- **katana**: Web crawler for discovering URLs

### 3. Username Extraction
Analyzes collected URLs using regex patterns to extract potential usernames from social media platforms.

### 4. Availability Check
For each platform, the tool:
- Makes HTTP requests to check if profiles exist
- Analyzes response codes and content
- Implements rate limiting to avoid detection
- Reports usernames that appear to be available

## Performance Considerations

- **Large Scale**: The tool can process millions of URLs, which may take considerable time
- **Rate Limiting**: Built-in delays prevent overwhelming target platforms
- **Memory Usage**: Large link collections are processed efficiently using file streaming
- **Network**: Requires stable internet connection for external tool operations

## Ethical Considerations

⚠️ **Important**: This tool is for educational and authorized security research purposes only.

- Only use on domains you own or have explicit permission to test
- Respect platform terms of service and rate limits
- Do not use for malicious purposes or unauthorized access
- Consider the ethical implications of username squatting
- Be aware of legal restrictions in your jurisdiction

## Troubleshooting

### Common Issues

1. **Tools not found**: Ensure Go tools are installed and in PATH
2. **Permission denied**: Make sure scripts are executable (`chmod +x`)
3. **Network timeouts**: Check internet connection and consider using VPN
4. **Rate limiting**: Tool includes delays, but some platforms may still block requests

### Debug Mode

Run with `--verbose` flag to see detailed execution information:

```bash
python3 broken_link_hijacker.py --target example.com --verbose
```

## Contributing

This tool can be extended with:
- Additional platform checkers
- Improved username extraction patterns
- Better rate limiting strategies
- Enhanced error handling
- Performance optimizations

## Disclaimer

This tool is provided for educational and authorized security research purposes only. Users are responsible for ensuring their use complies with applicable laws and platform terms of service. The authors are not responsible for any misuse or damage caused by this tool.

## License

This project is provided as-is for educational purposes. Use responsibly and in accordance with applicable laws and regulations.

