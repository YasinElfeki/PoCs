#!/usr/bin/env python3
"""
Broken Link Hijacking Tool

This tool automates the process of finding available usernames on social media platforms
by analyzing broken links from target domains.

Author: Manus AI
"""

import argparse
import os
import sys
import subprocess
import logging
import time
from pathlib import Path
import requests
import json
import re
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

class BrokenLinkHijacker:
    def __init__(self, target_domain, output_dir, verbose=False):
        self.target_domain = target_domain
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        log_level = logging.DEBUG if verbose else logging.INFO
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(self.output_dir / 'tool.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
        # File paths
        self.subdomains_file = self.output_dir / 'subdomains.txt'
        self.links_file = self.output_dir / 'all_links.txt'
        self.usernames_file = self.output_dir / 'extracted_usernames.txt'
        self.available_usernames_file = self.output_dir / 'available_usernames.txt'
        
        # Thread lock for file writing
        self.file_lock = threading.Lock()
        
    def run_command(self, command, capture_output=True):
        """Run a shell command and return the result."""
        try:
            self.logger.debug(f"Running command: {command}")
            result = subprocess.run(
                command, 
                shell=True, 
                capture_output=capture_output, 
                text=True, 
                timeout=3600  # 1 hour timeout
            )
            if result.returncode != 0:
                self.logger.error(f"Command failed: {command}")
                self.logger.error(f"Error: {result.stderr}")
                return None
            return result.stdout
        except subprocess.TimeoutExpired:
            self.logger.error(f"Command timed out: {command}")
            return None
        except Exception as e:
            self.logger.error(f"Error running command: {command} - {str(e)}")
            return None
    
    def collect_subdomains(self, skip_existing=False):
        """Collect subdomains for the target domain."""
        if skip_existing and self.subdomains_file.exists():
            self.logger.info(f"Skipping subdomain collection. Using existing file: {self.subdomains_file}")
            return
        
        self.logger.info(f"Starting subdomain collection for {self.target_domain}")
        
        # Check if tools are available
        tools = ['subfinder', 'assetfinder']
        available_tools = []
        
        for tool in tools:
            if self.run_command(f"which {tool}") is not None:
                available_tools.append(tool)
            else:
                self.logger.warning(f"{tool} not found. Skipping.")
        
        if not available_tools:
            self.logger.error("No subdomain enumeration tools found. Please install subfinder or assetfinder.")
            # Create a basic subdomain file with just the target domain
            with open(self.subdomains_file, 'w') as f:
                f.write(f"{self.target_domain}\n")
                f.write(f"www.{self.target_domain}\n")
            return
        
        all_subdomains = set()
        
        # Run available tools
        for tool in available_tools:
            self.logger.info(f"Running {tool} for subdomain enumeration...")
            if tool == 'subfinder':
                output = self.run_command(f"subfinder -d {self.target_domain} -silent")
            elif tool == 'assetfinder':
                output = self.run_command(f"assetfinder --subs-only {self.target_domain}")
            
            if output:
                subdomains = [line.strip() for line in output.split('\n') if line.strip()]
                all_subdomains.update(subdomains)
                self.logger.info(f"{tool} found {len(subdomains)} subdomains")
        
        # Write subdomains to file
        with open(self.subdomains_file, 'w') as f:
            for subdomain in sorted(all_subdomains):
                f.write(f"{subdomain}\n")
        
        self.logger.info(f"Total unique subdomains collected: {len(all_subdomains)}")
        self.logger.info(f"Subdomains saved to: {self.subdomains_file}")
    
    def collect_links(self, skip_existing=False):
        """Collect links from subdomains using various tools."""
        if skip_existing and self.links_file.exists():
            self.logger.info(f"Skipping link collection. Using existing file: {self.links_file}")
            return
        
        if not self.subdomains_file.exists():
            self.logger.error("Subdomains file not found. Run subdomain collection first.")
            return
        
        self.logger.info("Starting link collection from subdomains")
        
        # Read subdomains
        with open(self.subdomains_file, 'r') as f:
            subdomains = [line.strip() for line in f if line.strip()]
        
        self.logger.info(f"Processing {len(subdomains)} subdomains for link collection")
        
        # Check available tools
        tools = ['gau', 'haktrails', 'katana']
        available_tools = []
        
        for tool in tools:
            if self.run_command(f"which {tool}") is not None:
                available_tools.append(tool)
            else:
                self.logger.warning(f"{tool} not found. Skipping.")
        
        if not available_tools:
            self.logger.error("No link collection tools found. Please install gau, haktrails, or katana.")
            return
        
        # Create/clear the links file
        with open(self.links_file, 'w') as f:
            pass
        
        total_links = 0
        
        for i, subdomain in enumerate(subdomains, 1):
            self.logger.info(f"Processing subdomain {i}/{len(subdomains)}: {subdomain}")
            
            for tool in available_tools:
                try:
                    if tool == 'gau':
                        output = self.run_command(f"echo {subdomain} | gau")
                    elif tool == 'haktrails':
                        output = self.run_command(f"echo {subdomain} | haktrails urls")
                    elif tool == 'katana':
                        output = self.run_command(f"echo {subdomain} | katana -silent")
                    
                    if output:
                        links = [line.strip() for line in output.split('\n') if line.strip()]
                        
                        # Append links to file
                        with open(self.links_file, 'a') as f:
                            for link in links:
                                f.write(f"{link}\n")
                        
                        total_links += len(links)
                        self.logger.debug(f"{tool} found {len(links)} links for {subdomain}")
                
                except Exception as e:
                    self.logger.error(f"Error processing {subdomain} with {tool}: {str(e)}")
        
        self.logger.info(f"Total links collected: {total_links}")
        self.logger.info(f"Links saved to: {self.links_file}")
    
    def extract_usernames(self, skip_existing=False):
        """Extract usernames from collected links."""
        if skip_existing and self.usernames_file.exists():
            self.logger.info(f"Skipping username extraction. Using existing file: {self.usernames_file}")
            return
        
        if not self.links_file.exists():
            self.logger.error("Links file not found. Run link collection first.")
            return
        
        self.logger.info("Starting username extraction from links")
        
        # Social media patterns
        patterns = {
            'instagram': r'instagram\.com/([a-zA-Z0-9_.]+)',
            'twitter': r'twitter\.com/([a-zA-Z0-9_]+)',
            'facebook': r'facebook\.com/([a-zA-Z0-9.]+)',
            'linkedin': r'linkedin\.com/in/([a-zA-Z0-9-]+)',
            'github': r'github\.com/([a-zA-Z0-9-]+)',
            'youtube': r'youtube\.com/(?:user/|channel/|c/)?([a-zA-Z0-9_-]+)',
            'tiktok': r'tiktok\.com/@([a-zA-Z0-9_.]+)',
            'snapchat': r'snapchat\.com/add/([a-zA-Z0-9_.]+)'
        }
        
        usernames = set()
        
        self.logger.info("Processing links for username extraction...")
        
        with open(self.links_file, 'r') as f:
            for line_num, line in enumerate(f, 1):
                if line_num % 100000 == 0:
                    self.logger.info(f"Processed {line_num} links, found {len(usernames)} unique usernames")
                
                line = line.strip()
                if not line:
                    continue
                
                for platform, pattern in patterns.items():
                    matches = re.findall(pattern, line, re.IGNORECASE)
                    for match in matches:
                        # Clean username
                        username = match.lower().strip()
                        # Filter out common non-usernames
                        if (len(username) > 2 and 
                            not username.startswith('.') and 
                            not username.endswith('.') and
                            username not in ['www', 'api', 'mobile', 'help', 'support', 'about', 'home']):
                            usernames.add(f"{platform}:{username}")
        
        # Write usernames to file
        with open(self.usernames_file, 'w') as f:
            for username in sorted(usernames):
                f.write(f"{username}\n")
        
        self.logger.info(f"Total unique usernames extracted: {len(usernames)}")
        self.logger.info(f"Usernames saved to: {self.usernames_file}")
    
    def check_username_availability(self, platforms=None, skip_existing=False):
        """Check availability of extracted usernames."""
        if skip_existing and self.available_usernames_file.exists():
            self.logger.info(f"Skipping availability check. Using existing file: {self.available_usernames_file}")
            return
        
        if not self.usernames_file.exists():
            self.logger.error("Usernames file not found. Run username extraction first.")
            return
        
        self.logger.info("Starting username availability check")
        
        # Read usernames
        with open(self.usernames_file, 'r') as f:
            all_usernames = [line.strip() for line in f if line.strip()]
        
        # Filter by platforms if specified
        if platforms:
            platform_list = [p.lower() for p in platforms]
            filtered_usernames = [u for u in all_usernames if u.split(':')[0] in platform_list]
        else:
            filtered_usernames = all_usernames
        
        self.logger.info(f"Checking availability for {len(filtered_usernames)} usernames")
        
        available_usernames = []
        
        # Process usernames by platform
        platform_usernames = {}
        for username_entry in filtered_usernames:
            platform, username = username_entry.split(':', 1)
            if platform not in platform_usernames:
                platform_usernames[platform] = []
            platform_usernames[platform].append(username)
        
        for platform, usernames in platform_usernames.items():
            self.logger.info(f"Checking {len(usernames)} usernames for {platform}")
            available = self._check_platform_usernames(platform, usernames)
            available_usernames.extend([f"{platform}:{u}" for u in available])
        
        # Write available usernames to file
        with open(self.available_usernames_file, 'w') as f:
            for username in available_usernames:
                f.write(f"{username}\n")
        
        self.logger.info(f"Total available usernames found: {len(available_usernames)}")
        self.logger.info(f"Available usernames saved to: {self.available_usernames_file}")
    
    def _check_platform_usernames(self, platform, usernames):
        """Check username availability for a specific platform."""
        available = []
        
        if platform == 'instagram':
            available = self._check_instagram_usernames(usernames)
        elif platform == 'twitter':
            available = self._check_twitter_usernames(usernames)
        elif platform == 'facebook':
            available = self._check_facebook_usernames(usernames)
        elif platform == 'github':
            available = self._check_github_usernames(usernames)
        else:
            self.logger.warning(f"No checker implemented for platform: {platform}")
        
        return available
    
    def _check_instagram_usernames(self, usernames):
        """Check Instagram username availability."""
        available = []
        session = requests.Session()
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        
        for username in usernames:
            try:
                # Check if profile exists
                url = f"https://www.instagram.com/{username}/"
                response = session.get(url, timeout=10)
                
                if response.status_code == 404:
                    available.append(username)
                    self.logger.debug(f"Instagram username available: {username}")
                elif response.status_code == 200:
                    self.logger.debug(f"Instagram username taken: {username}")
                else:
                    self.logger.debug(f"Instagram username check inconclusive for {username}: {response.status_code}")
                
                # Rate limiting
                time.sleep(1)
                
            except Exception as e:
                self.logger.error(f"Error checking Instagram username {username}: {str(e)}")
        
        return available
    
    def _check_twitter_usernames(self, usernames):
        """Check Twitter username availability."""
        available = []
        session = requests.Session()
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        
        for username in usernames:
            try:
                # Check if profile exists
                url = f"https://twitter.com/{username}"
                response = session.get(url, timeout=10)
                
                if "This account doesn't exist" in response.text or response.status_code == 404:
                    available.append(username)
                    self.logger.debug(f"Twitter username available: {username}")
                elif response.status_code == 200:
                    self.logger.debug(f"Twitter username taken: {username}")
                else:
                    self.logger.debug(f"Twitter username check inconclusive for {username}: {response.status_code}")
                
                # Rate limiting
                time.sleep(1)
                
            except Exception as e:
                self.logger.error(f"Error checking Twitter username {username}: {str(e)}")
        
        return available
    
    def _check_facebook_usernames(self, usernames):
        """Check Facebook username availability."""
        available = []
        session = requests.Session()
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        
        for username in usernames:
            try:
                # Check if profile exists
                url = f"https://www.facebook.com/{username}"
                response = session.get(url, timeout=10)
                
                if "Page Not Found" in response.text or response.status_code == 404:
                    available.append(username)
                    self.logger.debug(f"Facebook username available: {username}")
                elif response.status_code == 200:
                    self.logger.debug(f"Facebook username taken: {username}")
                else:
                    self.logger.debug(f"Facebook username check inconclusive for {username}: {response.status_code}")
                
                # Rate limiting
                time.sleep(2)
                
            except Exception as e:
                self.logger.error(f"Error checking Facebook username {username}: {str(e)}")
        
        return available
    
    def _check_github_usernames(self, usernames):
        """Check GitHub username availability."""
        available = []
        session = requests.Session()
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        
        for username in usernames:
            try:
                # Check if profile exists
                url = f"https://github.com/{username}"
                response = session.get(url, timeout=10)
                
                if response.status_code == 404:
                    available.append(username)
                    self.logger.debug(f"GitHub username available: {username}")
                elif response.status_code == 200:
                    self.logger.debug(f"GitHub username taken: {username}")
                else:
                    self.logger.debug(f"GitHub username check inconclusive for {username}: {response.status_code}")
                
                # Rate limiting
                time.sleep(1)
                
            except Exception as e:
                self.logger.error(f"Error checking GitHub username {username}: {str(e)}")
        
        return available

def main():
    parser = argparse.ArgumentParser(description='Broken Link Hijacking Tool')
    parser.add_argument('--target', required=True, help='Target domain (e.g., example.com)')
    parser.add_argument('--output-dir', default='./results', help='Output directory for results')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose logging')
    parser.add_argument('--skip-subdomain-collection', action='store_true', help='Skip subdomain collection')
    parser.add_argument('--skip-link-collection', action='store_true', help='Skip link collection')
    parser.add_argument('--skip-username-extraction', action='store_true', help='Skip username extraction')
    parser.add_argument('--skip-availability-check', action='store_true', help='Skip availability check')
    parser.add_argument('--platforms', help='Comma-separated list of platforms to check (e.g., instagram,twitter)')
    
    args = parser.parse_args()
    
    # Parse platforms
    platforms = None
    if args.platforms:
        platforms = [p.strip() for p in args.platforms.split(',')]
    
    # Initialize tool
    tool = BrokenLinkHijacker(args.target, args.output_dir, args.verbose)
    
    try:
        # Run the tool
        if not args.skip_subdomain_collection:
            tool.collect_subdomains()
        
        if not args.skip_link_collection:
            tool.collect_links()
        
        if not args.skip_username_extraction:
            tool.extract_usernames()
        
        if not args.skip_availability_check:
            tool.check_username_availability(platforms)
        
        tool.logger.info("Tool execution completed successfully!")
        tool.logger.info(f"Results saved in: {tool.output_dir}")
        
    except KeyboardInterrupt:
        tool.logger.info("Tool execution interrupted by user")
        sys.exit(1)
    except Exception as e:
        tool.logger.error(f"Tool execution failed: {str(e)}")
        sys.exit(1)

if __name__ == '__main__':
    main()

