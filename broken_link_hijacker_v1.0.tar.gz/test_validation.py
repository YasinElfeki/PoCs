#!/usr/bin/env python3
"""
Test validation script for the broken link hijacking tool.
"""

import os
import sys
import subprocess
import tempfile
import shutil
from pathlib import Path

def run_test(test_name, command, expected_files=None, expected_content=None):
    """Run a test and validate results."""
    print(f"\n{'='*50}")
    print(f"Running test: {test_name}")
    print(f"{'='*50}")
    
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=60)
        
        if result.returncode != 0:
            print(f"❌ Test failed with return code {result.returncode}")
            print(f"STDERR: {result.stderr}")
            return False
        
        print(f"✅ Command executed successfully")
        
        # Check expected files
        if expected_files:
            for file_path in expected_files:
                if os.path.exists(file_path):
                    print(f"✅ Expected file exists: {file_path}")
                else:
                    print(f"❌ Expected file missing: {file_path}")
                    return False
        
        # Check expected content
        if expected_content:
            for file_path, expected_lines in expected_content.items():
                if os.path.exists(file_path):
                    with open(file_path, 'r') as f:
                        content = f.read().strip()
                        lines = content.split('\n') if content else []
                        if len(lines) >= expected_lines:
                            print(f"✅ File has expected content: {file_path} ({len(lines)} lines)")
                        else:
                            print(f"❌ File has insufficient content: {file_path} ({len(lines)} lines, expected >= {expected_lines})")
                            return False
                else:
                    print(f"❌ File not found for content check: {file_path}")
                    return False
        
        return True
        
    except subprocess.TimeoutExpired:
        print(f"❌ Test timed out")
        return False
    except Exception as e:
        print(f"❌ Test failed with exception: {str(e)}")
        return False

def main():
    """Run all validation tests."""
    print("Starting validation tests for Broken Link Hijacking Tool")
    
    # Create test directory
    test_dir = "validation_test"
    if os.path.exists(test_dir):
        shutil.rmtree(test_dir)
    os.makedirs(test_dir)
    
    # Test data
    sample_links = """https://www.instagram.com/testuser123
https://twitter.com/sampleuser
https://facebook.com/examplepage
https://github.com/developer123
https://linkedin.com/in/professional-user
https://youtube.com/user/contentcreator
https://tiktok.com/@funnyvideos
https://snapchat.com/add/snapuser"""
    
    with open(f"{test_dir}/all_links.txt", 'w') as f:
        f.write(sample_links)
    
    tests_passed = 0
    total_tests = 0
    
    # Test 1: Help command
    total_tests += 1
    if run_test(
        "Help Command",
        "python3 broken_link_hijacker.py --help"
    ):
        tests_passed += 1
    
    # Test 2: Username extraction only
    total_tests += 1
    if run_test(
        "Username Extraction",
        f"python3 broken_link_hijacker.py --target example.com --output-dir {test_dir} --skip-subdomain-collection --skip-link-collection --skip-availability-check",
        expected_files=[f"{test_dir}/extracted_usernames.txt"],
        expected_content={f"{test_dir}/extracted_usernames.txt": 5}
    ):
        tests_passed += 1
    
    # Test 3: GitHub availability check (limited test)
    sample_usernames = """github:nonexistentuser12345
github:torvalds"""
    
    with open(f"{test_dir}/extracted_usernames.txt", 'w') as f:
        f.write(sample_usernames)
    
    total_tests += 1
    if run_test(
        "GitHub Availability Check",
        f"python3 broken_link_hijacker.py --target example.com --output-dir {test_dir} --skip-subdomain-collection --skip-link-collection --skip-username-extraction --platforms github",
        expected_files=[f"{test_dir}/available_usernames.txt"]
    ):
        tests_passed += 1
    
    # Test 4: Verbose logging
    total_tests += 1
    if run_test(
        "Verbose Logging",
        f"python3 broken_link_hijacker.py --target example.com --output-dir {test_dir} --skip-subdomain-collection --skip-link-collection --skip-availability-check --verbose",
        expected_files=[f"{test_dir}/tool.log"]
    ):
        tests_passed += 1
    
    # Cleanup
    shutil.rmtree(test_dir)
    
    # Results
    print(f"\n{'='*50}")
    print(f"VALIDATION RESULTS")
    print(f"{'='*50}")
    print(f"Tests passed: {tests_passed}/{total_tests}")
    
    if tests_passed == total_tests:
        print("🎉 All tests passed! Tool is working correctly.")
        return 0
    else:
        print("❌ Some tests failed. Please check the implementation.")
        return 1

if __name__ == '__main__':
    sys.exit(main())

